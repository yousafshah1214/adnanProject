    <footer class="site-footer site-top-footer">
    	<div class="container">
        	<div class="row">
            	<div class="col-md-3 col-sm-6 footer-widget widget text_widget">
                	<h4 class="widgettitle">USEFUL LINKS</h4>
                <ul>
                        	<li><a href="#">Gallery</a></li>
                            <li><a href="#">Alumni</a></li>
                            <li><a href="#">Latest News</a></li>
                            <li><a href="#">Student success stories</a></li>
                        </ul>

				</div>
            	<div class="col-md-3 col-sm-6 footer-widget widget text_widget">
                	<h4 class="widgettitle">RELATED LINKS</h4>
                    <ul>
                        	<li><a href="#">Link1</a></li>
                            <li><a href="#">Link1</a></li>
                            <li><a href="#">Link1</a></li>
                            <li><a href="#">Link1</a></li>
                        </ul>

                </div>
            	<div class="col-md-3 col-sm-6 footer-widget widget text_widget">
                	<h4 class="widgettitle">LEGALS LINKS</h4>
                    <ul>
                        	<li><a href="#">Term & Condition</a></li>
                            <li><a href="#">Privacy Policy</a></li>
                            <li><a href="#">Faqs</a></li>
                            <li><a href="#">Link1</a></li>
                        </ul>

                </div>
              	<div class="col-md-3 col-sm-6 footer-widget widget text_widget">
                	<h4 class="widgettitle">Our Location</h4>
                    <p>Project Coordinator (PNSSP) Satellite Research & Development Centre<br>SUPARCO Road, Lahore. 54590</p>
					<p><a href="pnssp.coordinator@suparco.gov.pk">pnssp.coordinator@suparco.gov.pk</a><br>Tel: 042-35904292<br/>Fax: 042-35293060</p>
                </div>
            </div>
        </div>
    </footer>
    <footer class="site-footer site-bottom-footer">
    	<div class="container">
        	<div class="row">
            	<div class="col-md-4 col-sm-4">
                	<p>Copyright &copy; 2015, SUPARCO, Pakistan. All Rights Reserved.</p>
                </div>
            	<div class="col-md-8 col-sm-8">
                	<ul class="footer-nav">
                    	<li><a href="#">Home</a></li>
                    	<li><a href="#">About</a></li>
                    	<li><a href="#">Contact</a></li>
                    	<li><a href="#">FAQ</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>

    <script src="<?php echo base_url("includes/js/jquery-2.1.1.min.js"); ?>"></script> <!-- Jquery Library Call -->
    <script src="<?php echo base_url("includes/includes/prettyphoto/js/prettyphoto.js"); ?>"></script> <!-- PrettyPhoto Plugin -->
    <script src="<?php echo base_url("includes/js/helper-plugins.js"); ?>"></script> <!-- Helper Plugins -->
    <script src="<?php echo base_url("includes/js/bootstrap.js"); ?>"></script> <!-- UI -->
    <script src="<?php echo base_url("includes/js/init.js"); ?>"></script> <!-- All Scripts -->
    <script src="<?php echo base_url("includes/includes/flexslider/js/jquery.flexslider.js"); ?>"></script> <!-- FlexSlider -->
    <script src="<?php echo base_url("includes/includes/rs-plugin/js/jquery.plugins.min.js"); ?>"></script>
    <script src="<?php echo base_url("includes/includes/rs-plugin/js/jquery.revolution.min.js"); ?>"></script>
    <script src="<?php echo base_url("includes/js/revolution-slider-init.js"); ?>"></script> <!-- Revolutions Slider Intialization -->
    <script src="<?php echo base_url("includes/includes/countdown/js/jquery.countdown.min.js"); ?>"></script> <!-- Jquery Timer -->